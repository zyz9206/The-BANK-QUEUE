#pragma once

#include <QDialog>
#include "ui_cus1.h"
#include"ui_cus2.h"
#include"cus2.h"

class cus1 : public QDialog
{
	Q_OBJECT

public:
	cus1(QDialog *parent = Q_NULLPTR);
	~cus1();

private:
	Ui::cus1 ui;
	cus2 cus2;
private slots:

	void nor1_pushed();
	void nor2_pushed();
	void nor3_pushed();
	void spe1_pushed();
	void spe2_pushed();
};
