#include "cus2.h"
#include "ui_cus2.h"
#include "cus3.h"
#include "ui_cus3.h"
#include"myinclude.h"
#include<qmessagebox.h>
#include<qstring.h>
extern int win_templ;
extern map<string, cus> cusmap;
map<string, customer>::iterator it;
extern cus *cus_t;
string card_num, name;
cus2::cus2(QDialog *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

cus2::~cus2()
{
}
void cus2::ok_clicked() {
	if (ui.nameedit->text() == NULL || ui.numedit->text() == NULL) {
		QString a = "ERROR!";
		QString b = QString::fromLocal8Bit("����Ϊ�գ�");
		QMessageBox::warning(this, a, b);
		return;
	}
	card_num = ui.numedit->text().toStdString();
	name = ui.nameedit->text().toStdString();
	it = cusmap.find(card_num);
	if (it == cusmap.end() ){
		QString a = "ERROR!";
		QString b = QString::fromLocal8Bit("δ�ҵ���Ӧ����");
		QMessageBox::warning(this, a, b);
		return;
	}
	cus_t->card_balance = it->second.card_balance;
	this->hide();
	cus3.show();
	cus3.exec();
}