#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Umain.h"
#include "ui_Uqueue.h"
#include "ui_cus1.h"
#include "ui_cus2.h"
#include "ui_cus3.h"
#include "cus1.h"
#include "cus2.h"
#include "cus3.h"
#include "Uqueue.h"


class Umain : public QMainWindow
{
    Q_OBJECT

public:
    Umain(QDialog *parent = Q_NULLPTR);

private:
    Ui::UmainClass ui;
    cus1 cus1;
    Uqueue Uqueue;
private slots:
    void num_clicked();
    void cus_clicked();
    void exit_clicked();
    void time_clicked();
    void txt_updated();
};
