

#include "cus1.h"
#include"myinclude.h"
#include<qmessagebox.h>

int win_temp;
extern win nor[3], spe[2];
extern queue<cus> q_cusnor;//��ͨ�û��ȴ����� 
extern queue<cus> q_cusspe;//�����û��ȴ�����
extern int time_all, cus_all;
extern int norleft, speleft;
cus* cus_t;
cus1::cus1(QDialog *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

cus1::~cus1()
{
}

void cus1::nor2_pushed()
{
	win_temp = 1;
	if (nor[win_temp].free) {
		QString a = QString::fromLocal8Bit("����");
		QString b = QString::fromLocal8Bit("��ǰ�����޿ͻ���");
		QMessageBox::warning(this, a, b);
		return;
	}
	cus_t = &nor[win_temp].c;
	this->hide();
	cus2.show();
	cus2.exec();
	time_all += nor[win_temp].c.t_wait;
	cus_all++;
	if(q_cusnor.empty())nor[win_temp].free = true;
	else {
		nor[win_temp].c = q_cusnor.front();
		q_cusnor.pop();
	}
	norleft--;
}

void cus1::nor3_pushed()
{
	win_temp = 2;
	if (nor[win_temp].free) {
		QString a = QString::fromLocal8Bit("����");
		QString b = QString::fromLocal8Bit("��ǰ�����޿ͻ���");
		QMessageBox::warning(this, a, b);
		return;
	}
	cus_t = &nor[win_temp].c;
	this->hide();
	cus2.show();
	cus2.exec();
	time_all += nor[win_temp].c.t_wait;
	cus_all++;
	if (q_cusnor.empty())nor[win_temp].free = true;
	else {
		nor[win_temp].c = q_cusnor.front();
		q_cusnor.pop();
	}
	norleft--;
}

void cus1::spe1_pushed()
{
	win_temp = 0;
	if (spe[win_temp].free) {
		QString a = QString::fromLocal8Bit("����");
		QString b = QString::fromLocal8Bit("��ǰ�����޿ͻ���");
		QMessageBox::warning(this, a, b);
		return;
	}
	cus_t = &spe[win_temp].c;
	this->hide();
	cus2.show();
	cus2.exec();
	time_all += spe[win_temp].c.t_wait;
	cus_all++;
	if (q_cusspe.empty())spe[win_temp].free = true;
	else {
		spe[win_temp].c = q_cusspe.front();
		q_cusspe.pop();
	}
	speleft--;
}

void cus1::spe2_pushed()
{
	win_temp = 1;
	if (spe[win_temp].free) {
		QString a = QString::fromLocal8Bit("����");
		QString b = QString::fromLocal8Bit("��ǰ�����޿ͻ���");
		QMessageBox::warning(this, a, b);
		return;
	}
	cus_t = &spe[win_temp].c;
	this->hide();
	cus2.show();
	cus2.exec();
	time_all += spe[win_temp].c.t_wait;
	cus_all++;
	if (q_cusspe.empty())spe[win_temp].free = true;
	else {
		spe[win_temp].c = q_cusspe.front();
		q_cusspe.pop();
	}
	speleft--;
}
void cus1::nor1_pushed()
{
	win_temp = 0;
	if (nor[win_temp].free) {
		QString a = QString::fromLocal8Bit("����");
		QString b = QString::fromLocal8Bit("��ǰ�����޿ͻ���");
		QMessageBox::warning(this, a, b);
		return;
	}
	cus_t = &nor[win_temp].c;
	this->hide();
	cus2.show();
	cus2.exec();
	time_all += spe[win_temp].c.t_wait;
	cus_all++;
	if (q_cusnor.empty())nor[win_temp].free = true;
	else {
		nor[win_temp].c = q_cusnor.front();
		q_cusnor.pop();
	}
	norleft--;
}

