#pragma once

#include <QDialog>
#include "ui_Uqueue.h"

class Uqueue : public QDialog
{
	Q_OBJECT

public:
	Uqueue(QDialog*parent = Q_NULLPTR);
	~Uqueue();

private:
	Ui::Uqueue ui;
private slots:

	void nor_clicked();
	void spe_clicked();
	void num_updated();
};
