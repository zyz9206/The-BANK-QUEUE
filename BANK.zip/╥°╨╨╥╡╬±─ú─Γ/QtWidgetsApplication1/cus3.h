#pragma once

#include <QDialog>
#include "ui_cus3.h"

class cus3 : public QDialog
{
	Q_OBJECT

public:
	cus3(QDialog *parent = Q_NULLPTR);
	~cus3();

private:
	Ui::cus3 ui;
private slots:
	void qu_clicked();
	void cun_clicked();
	void cha_clicked();
//	void ok_clicked();
};
