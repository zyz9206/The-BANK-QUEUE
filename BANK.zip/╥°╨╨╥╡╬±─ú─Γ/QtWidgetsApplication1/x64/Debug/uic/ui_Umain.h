/********************************************************************************
** Form generated from reading UI file 'Umain.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UMAIN_H
#define UI_UMAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UmainClass
{
public:
    QWidget *centralWidget;
    QPushButton *pbexit;
    QPushButton *pbcus;
    QPlainTextEdit *plainTextEdit;
    QPushButton *pbgetnum;
    QPushButton *pbtime;
    QPushButton *pushButton;

    void setupUi(QMainWindow *UmainClass)
    {
        if (UmainClass->objectName().isEmpty())
            UmainClass->setObjectName(QString::fromUtf8("UmainClass"));
        UmainClass->resize(797, 642);
        UmainClass->setStyleSheet(QString::fromUtf8(""));
        centralWidget = new QWidget(UmainClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        pbexit = new QPushButton(centralWidget);
        pbexit->setObjectName(QString::fromUtf8("pbexit"));
        pbexit->setGeometry(QRect(670, 570, 93, 28));
        pbcus = new QPushButton(centralWidget);
        pbcus->setObjectName(QString::fromUtf8("pbcus"));
        pbcus->setGeometry(QRect(460, 320, 191, 91));
        QFont font;
        font.setFamily(QString::fromUtf8("Adobe Arabic"));
        font.setPointSize(16);
        pbcus->setFont(font);
        plainTextEdit = new QPlainTextEdit(centralWidget);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(180, 150, 471, 131));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Adobe Arabic"));
        font1.setPointSize(26);
        plainTextEdit->setFont(font1);
        pbgetnum = new QPushButton(centralWidget);
        pbgetnum->setObjectName(QString::fromUtf8("pbgetnum"));
        pbgetnum->setGeometry(QRect(160, 320, 191, 91));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Adobe Arabic"));
        font2.setPointSize(22);
        pbgetnum->setFont(font2);
        pbtime = new QPushButton(centralWidget);
        pbtime->setObjectName(QString::fromUtf8("pbtime"));
        pbtime->setGeometry(QRect(350, 470, 101, 41));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(360, 70, 93, 28));
        UmainClass->setCentralWidget(centralWidget);

        retranslateUi(UmainClass);
        QObject::connect(pbgetnum, SIGNAL(clicked()), UmainClass, SLOT(num_clicked()));
        QObject::connect(pbexit, SIGNAL(clicked()), UmainClass, SLOT(exit_clicked()));
        QObject::connect(pbcus, SIGNAL(clicked()), UmainClass, SLOT(cus_clicked()));
        QObject::connect(pbtime, SIGNAL(clicked()), UmainClass, SLOT(time_clicked()));
        QObject::connect(pushButton, SIGNAL(clicked()), UmainClass, SLOT(txt_updated()));

        QMetaObject::connectSlotsByName(UmainClass);
    } // setupUi

    void retranslateUi(QMainWindow *UmainClass)
    {
        UmainClass->setWindowTitle(QCoreApplication::translate("UmainClass", "Umain", nullptr));
        pbexit->setText(QCoreApplication::translate("UmainClass", "\351\200\200\345\207\272", nullptr));
        pbcus->setText(QCoreApplication::translate("UmainClass", "\345\256\242\346\210\267\344\270\232\345\212\241\345\212\236\347\220\206", nullptr));
        plainTextEdit->setPlainText(QCoreApplication::translate("UmainClass", "         \346\254\242\350\277\216\346\235\245\345\210\260xx\351\223\266\350\241\214\n"
"\350\257\267\351\200\211\346\213\251\346\202\250\350\246\201\350\277\233\350\241\214\347\232\204\346\234\215\345\212\241", nullptr));
        pbgetnum->setText(QCoreApplication::translate("UmainClass", "\345\217\226\345\217\267", nullptr));
        pbtime->setText(QCoreApplication::translate("UmainClass", "\346\227\266\351\227\264\350\256\241\347\256\227", nullptr));
        pushButton->setText(QCoreApplication::translate("UmainClass", "\345\206\231\345\205\245\346\226\207\344\273\266", nullptr));
    } // retranslateUi

};

namespace Ui {
    class UmainClass: public Ui_UmainClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UMAIN_H
