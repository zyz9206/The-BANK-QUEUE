/********************************************************************************
** Form generated from reading UI file 'Uqueue.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UQUEUE_H
#define UI_UQUEUE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Uqueue
{
public:
    QPushButton *pbnor;
    QPushButton *pbspe;
    QTextEdit *textEdit;
    QPushButton *pushButton;

    void setupUi(QDialog *Uqueue)
    {
        if (Uqueue->objectName().isEmpty())
            Uqueue->setObjectName(QString::fromUtf8("Uqueue"));
        Uqueue->resize(845, 600);
        pbnor = new QPushButton(Uqueue);
        pbnor->setObjectName(QString::fromUtf8("pbnor"));
        pbnor->setGeometry(QRect(120, 360, 231, 111));
        QFont font;
        font.setFamily(QString::fromUtf8("Adobe Arabic"));
        font.setPointSize(24);
        pbnor->setFont(font);
        pbnor->setCursor(QCursor(Qt::PointingHandCursor));
        pbspe = new QPushButton(Uqueue);
        pbspe->setObjectName(QString::fromUtf8("pbspe"));
        pbspe->setGeometry(QRect(460, 360, 231, 111));
        pbspe->setFont(font);
        pbspe->setCursor(QCursor(Qt::PointingHandCursor));
        textEdit = new QTextEdit(Uqueue);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(170, 100, 491, 201));
        pushButton = new QPushButton(Uqueue);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(710, 190, 93, 28));

        retranslateUi(Uqueue);
        QObject::connect(pbnor, SIGNAL(clicked()), Uqueue, SLOT(nor_clicked()));
        QObject::connect(pbspe, SIGNAL(clicked()), Uqueue, SLOT(spe_clicked()));
        QObject::connect(pushButton, SIGNAL(clicked()), Uqueue, SLOT(num_updated()));

        QMetaObject::connectSlotsByName(Uqueue);
    } // setupUi

    void retranslateUi(QDialog *Uqueue)
    {
        Uqueue->setWindowTitle(QCoreApplication::translate("Uqueue", "Uqueue", nullptr));
        pbnor->setText(QCoreApplication::translate("Uqueue", "\346\231\256\351\200\232\344\270\232\345\212\241", nullptr));
        pbspe->setText(QCoreApplication::translate("Uqueue", "\347\211\271\346\256\212\344\270\232\345\212\241", nullptr));
        textEdit->setHtml(QCoreApplication::translate("Uqueue", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:22pt;\">\345\211\215\346\226\271</span></p>\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:22pt;\">\350\277\230\346\234\2110\345\220\215\346\231\256\351\200\232\347\224\250\346\210\267\346\255\243\345\234\250\347\255\211\345\276\205</span></p>\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0"
                        "; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:22pt;\">\350\277\230\346\234\2110\345\220\215\347\211\271\346\256\212\347\224\250\346\210\267\346\255\243\345\234\250\347\255\211\345\276\205</span></p>\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:22pt;\">\350\257\267\351\200\211\346\213\251\346\202\250\347\232\204\344\270\232\345\212\241\347\261\273\345\236\213</span></p></body></html>", nullptr));
        pushButton->setText(QCoreApplication::translate("Uqueue", "\346\233\264\346\226\260\346\225\260\346\215\256", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Uqueue: public Ui_Uqueue {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UQUEUE_H
