/********************************************************************************
** Form generated from reading UI file 'cus3.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUS3_H
#define UI_CUS3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_cus3
{
public:
    QTextEdit *textEdit;
    QPushButton *rbcha;
    QLineEdit *moneyin;
    QPushButton *rbcun;
    QPushButton *rbqu;
    QLineEdit *time_intxt;
    QLineEdit *time_outtxt;
    QTextEdit *textEdit_2;
    QTextEdit *textEdit_3;

    void setupUi(QDialog *cus3)
    {
        if (cus3->objectName().isEmpty())
            cus3->setObjectName(QString::fromUtf8("cus3"));
        cus3->resize(811, 599);
        textEdit = new QTextEdit(cus3);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(180, 330, 121, 31));
        rbcha = new QPushButton(cus3);
        rbcha->setObjectName(QString::fromUtf8("rbcha"));
        rbcha->setGeometry(QRect(560, 430, 121, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("Adobe Arabic"));
        font.setPointSize(11);
        rbcha->setFont(font);
        moneyin = new QLineEdit(cus3);
        moneyin->setObjectName(QString::fromUtf8("moneyin"));
        moneyin->setGeometry(QRect(340, 340, 221, 21));
        rbcun = new QPushButton(cus3);
        rbcun->setObjectName(QString::fromUtf8("rbcun"));
        rbcun->setGeometry(QRect(180, 430, 121, 31));
        rbcun->setFont(font);
        rbqu = new QPushButton(cus3);
        rbqu->setObjectName(QString::fromUtf8("rbqu"));
        rbqu->setGeometry(QRect(370, 430, 115, 31));
        rbqu->setFont(font);
        time_intxt = new QLineEdit(cus3);
        time_intxt->setObjectName(QString::fromUtf8("time_intxt"));
        time_intxt->setGeometry(QRect(230, 200, 113, 21));
        time_outtxt = new QLineEdit(cus3);
        time_outtxt->setObjectName(QString::fromUtf8("time_outtxt"));
        time_outtxt->setGeometry(QRect(460, 200, 113, 21));
        textEdit_2 = new QTextEdit(cus3);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(230, 150, 111, 31));
        textEdit_3 = new QTextEdit(cus3);
        textEdit_3->setObjectName(QString::fromUtf8("textEdit_3"));
        textEdit_3->setGeometry(QRect(460, 150, 111, 31));

        retranslateUi(cus3);
        QObject::connect(rbcun, SIGNAL(clicked()), cus3, SLOT(cun_clicked()));
        QObject::connect(rbqu, SIGNAL(clicked()), cus3, SLOT(qu_clicked()));
        QObject::connect(rbcha, SIGNAL(clicked()), cus3, SLOT(cha_clicked()));

        QMetaObject::connectSlotsByName(cus3);
    } // setupUi

    void retranslateUi(QDialog *cus3)
    {
        cus3->setWindowTitle(QCoreApplication::translate("cus3", "cus3", nullptr));
        textEdit->setHtml(QCoreApplication::translate("cus3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">\350\257\267\350\276\223\345\205\245\351\207\221\351\242\235\357\274\232</span></p></body></html>", nullptr));
        rbcha->setText(QCoreApplication::translate("cus3", "\344\273\205\346\237\245\350\257\242\344\275\231\351\242\235", nullptr));
        rbcun->setText(QCoreApplication::translate("cus3", "\345\255\230\346\254\276", nullptr));
        rbqu->setText(QCoreApplication::translate("cus3", "\345\217\226\346\254\276", nullptr));
        time_intxt->setText(QCoreApplication::translate("cus3", "0", nullptr));
        time_outtxt->setText(QCoreApplication::translate("cus3", "0", nullptr));
        textEdit_2->setHtml(QCoreApplication::translate("cus3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">\345\274\200\345\247\213\346\227\266\351\227\264\357\274\232</span></p></body></html>", nullptr));
        textEdit_3->setHtml(QCoreApplication::translate("cus3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">\347\273\223\346\235\237\346\227\266\351\227\264\357\274\232</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cus3: public Ui_cus3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUS3_H
