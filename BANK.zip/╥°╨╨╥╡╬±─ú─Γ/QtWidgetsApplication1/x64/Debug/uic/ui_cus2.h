/********************************************************************************
** Form generated from reading UI file 'cus2.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUS2_H
#define UI_CUS2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_cus2
{
public:
    QTextEdit *textEdit_3;
    QLineEdit *nameedit;
    QPushButton *pbok;
    QTextEdit *textEdit_2;
    QTextEdit *textEdit;
    QLineEdit *numedit;

    void setupUi(QDialog *cus2)
    {
        if (cus2->objectName().isEmpty())
            cus2->setObjectName(QString::fromUtf8("cus2"));
        cus2->resize(858, 597);
        textEdit_3 = new QTextEdit(cus2);
        textEdit_3->setObjectName(QString::fromUtf8("textEdit_3"));
        textEdit_3->setGeometry(QRect(180, 390, 81, 31));
        nameedit = new QLineEdit(cus2);
        nameedit->setObjectName(QString::fromUtf8("nameedit"));
        nameedit->setGeometry(QRect(270, 300, 401, 31));
        pbok = new QPushButton(cus2);
        pbok->setObjectName(QString::fromUtf8("pbok"));
        pbok->setGeometry(QRect(632, 487, 101, 41));
        textEdit_2 = new QTextEdit(cus2);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(180, 300, 81, 31));
        textEdit = new QTextEdit(cus2);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(270, 160, 331, 51));
        numedit = new QLineEdit(cus2);
        numedit->setObjectName(QString::fromUtf8("numedit"));
        numedit->setGeometry(QRect(270, 390, 401, 31));

        retranslateUi(cus2);
        QObject::connect(pbok, SIGNAL(clicked()), cus2, SLOT(ok_clicked()));

        QMetaObject::connectSlotsByName(cus2);
    } // setupUi

    void retranslateUi(QDialog *cus2)
    {
        cus2->setWindowTitle(QCoreApplication::translate("cus2", "cus2", nullptr));
        textEdit_3->setHtml(QCoreApplication::translate("cus2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:11pt; font-weight:600;\">\345\215\241\345\217\267\357\274\232</span></p></body></html>", nullptr));
        pbok->setText(QCoreApplication::translate("cus2", "\347\241\256\345\256\232", nullptr));
        textEdit_2->setHtml(QCoreApplication::translate("cus2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:11pt; font-weight:600;\">\345\247\223\345\220\215\357\274\232</span></p></body></html>", nullptr));
        textEdit->setHtml(QCoreApplication::translate("cus2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:20pt; font-weight:600;\">\350\257\267\350\276\223\345\205\245\345\247\223\345\220\215\345\222\214\345\215\241\345\217\267</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cus2: public Ui_cus2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUS2_H
