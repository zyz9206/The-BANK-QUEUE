/********************************************************************************
** Form generated from reading UI file 'cus1.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUS1_H
#define UI_CUS1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_cus1
{
public:
    QPushButton *pbspe1;
    QPushButton *pbnor1;
    QPushButton *pbnor3;
    QPushButton *pbspe2;
    QTextEdit *textEdit;
    QPushButton *pbnor2;

    void setupUi(QDialog *cus1)
    {
        if (cus1->objectName().isEmpty())
            cus1->setObjectName(QString::fromUtf8("cus1"));
        cus1->resize(787, 602);
        pbspe1 = new QPushButton(cus1);
        pbspe1->setObjectName(QString::fromUtf8("pbspe1"));
        pbspe1->setGeometry(QRect(190, 410, 141, 51));
        pbspe1->setCursor(QCursor(Qt::PointingHandCursor));
        pbnor1 = new QPushButton(cus1);
        pbnor1->setObjectName(QString::fromUtf8("pbnor1"));
        pbnor1->setGeometry(QRect(70, 290, 141, 51));
        pbnor1->setCursor(QCursor(Qt::PointingHandCursor));
        pbnor3 = new QPushButton(cus1);
        pbnor3->setObjectName(QString::fromUtf8("pbnor3"));
        pbnor3->setGeometry(QRect(570, 290, 141, 51));
        pbnor3->setCursor(QCursor(Qt::PointingHandCursor));
        pbspe2 = new QPushButton(cus1);
        pbspe2->setObjectName(QString::fromUtf8("pbspe2"));
        pbspe2->setGeometry(QRect(450, 410, 141, 51));
        pbspe2->setCursor(QCursor(Qt::PointingHandCursor));
        textEdit = new QTextEdit(cus1);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(210, 150, 361, 81));
        pbnor2 = new QPushButton(cus1);
        pbnor2->setObjectName(QString::fromUtf8("pbnor2"));
        pbnor2->setGeometry(QRect(320, 290, 141, 51));
        pbnor2->setCursor(QCursor(Qt::PointingHandCursor));

        retranslateUi(cus1);
        QObject::connect(pbnor1, SIGNAL(clicked()), cus1, SLOT(nor1_pushed()));
        QObject::connect(pbnor2, SIGNAL(clicked()), cus1, SLOT(nor2_pushed()));
        QObject::connect(pbnor3, SIGNAL(clicked()), cus1, SLOT(nor3_pushed()));
        QObject::connect(pbspe1, SIGNAL(clicked()), cus1, SLOT(spe1_pushed()));
        QObject::connect(pbspe2, SIGNAL(clicked()), cus1, SLOT(spe2_pushed()));

        QMetaObject::connectSlotsByName(cus1);
    } // setupUi

    void retranslateUi(QDialog *cus1)
    {
        cus1->setWindowTitle(QCoreApplication::translate("cus1", "cus1", nullptr));
        pbspe1->setText(QCoreApplication::translate("cus1", "\347\211\271\346\256\212\347\252\227\345\217\2431", nullptr));
        pbnor1->setText(QCoreApplication::translate("cus1", "\346\231\256\351\200\232\347\252\227\345\217\2431", nullptr));
        pbnor3->setText(QCoreApplication::translate("cus1", "\346\231\256\351\200\232\347\252\227\345\217\2433", nullptr));
        pbspe2->setText(QCoreApplication::translate("cus1", "\347\211\271\346\256\212\347\252\227\345\217\2432", nullptr));
        textEdit->setHtml(QCoreApplication::translate("cus1", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:20pt; font-weight:600;\">\350\257\267\351\200\211\346\213\251\350\246\201\345\244\204\347\220\206\347\232\204\347\252\227\345\217\243\345\217\267</span></p></body></html>", nullptr));
        pbnor2->setText(QCoreApplication::translate("cus1", "\346\231\256\351\200\232\347\252\227\345\217\2432", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cus1: public Ui_cus1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUS1_H
