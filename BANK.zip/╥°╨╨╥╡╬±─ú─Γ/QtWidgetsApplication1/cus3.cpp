#include "cus3.h"
#include"myinclude.h"
#include<qstring.h>
#include"ui_cus3.h"
#include<qmessagebox.h>
extern map<string, cus> cusmap;
extern cus *cus_t;
extern int win_temp;
extern win nor[3], spe[2];//������ͨ���ڣ�����vip 
extern queue<cus> q_cusnor;//��ͨ�û��ȴ����� 
extern queue<cus> q_cusspe;//�����û��ȴ�����
extern map<string, customer>::iterator it;

cus3::cus3(QDialog *parent)
	: QDialog (parent)
{
	ui.setupUi(this);
}

cus3::~cus3()
{
}

void cus3::qu_clicked()
{
	int ti, to;
	ti = ui.time_intxt->text().toInt();
	to = ui.time_outtxt->text().toInt();
	int time = to - ti;
	cus_t->e.time = time;
	queue<cus> tq;
	while (!q_cusnor.empty()) {
		tq.push(q_cusnor.front());
		q_cusnor.front().t_wait += nor[win_temp].c.e.time;
		tq.pop();
	}
	while (!tq.empty()) {
		q_cusnor.push(tq.front());
		tq.pop();
	}
	if (!q_cusnor.empty()) {
		nor[win_temp].c = q_cusnor.front();
		q_cusnor.pop();
	}
		if (ui.moneyin->text() == NULL) {
			QString a = "WARNING!";
			QString b = QString::fromLocal8Bit("����Ϊ�գ�");
			QMessageBox::warning(this, a, b);
			return;
		}
		int money_t = ui.moneyin->text().toInt();
		it->second.card_balance -= money_t;
		QString a = "OK!";
		QString b = QString::fromLocal8Bit("�ɹ�ȡ�");
		QMessageBox::warning(this, a, b);
		this->close();
}

void cus3::cun_clicked()
{
	int ti, to;
	ti = ui.time_intxt->text().toInt();
	to = ui.time_outtxt->text().toInt();
	int time = to - ti;
	cus_t->e.time = time;
	queue<cus> tq;
	while (!q_cusnor.empty()) {
		tq.push(q_cusnor.front());
		q_cusnor.front().t_wait += nor[win_temp].c.e.time;
		tq.pop();
	}
	while (!tq.empty()) {
		q_cusnor.push(tq.front());
		tq.pop();
	}
	if (!q_cusnor.empty()) {
		nor[win_temp].c = q_cusnor.front();
		q_cusnor.pop();
	}
	if (ui.moneyin->text() == NULL) {
		QString a = "WARNING!";
		QString b = QString::fromLocal8Bit("����Ϊ�գ�");
		QMessageBox::warning(this, a, b);
		return;
	}
	int money_t = ui.moneyin->text().toInt();
	it->second.card_balance += money_t;
	QString a = "OK!";
	QString b = QString::fromLocal8Bit("�ɹ���");
	QMessageBox::warning(this, a, b);
	this->close();
}

void cus3::cha_clicked()
{
	QString a = QString::fromLocal8Bit("ʣ����Ϊ");
	QString b = QString::number(it->second.card_balance);
	QMessageBox::warning(this, a, b);
	this->close();
}

//void cus3::ok_clicked()
//{
//	//QString ti, to;
//	int ti, to;
//	ti = ui.time_intxt->text().toInt();
//	to = ui.time_outtxt->text().toInt();
//	int time = to - ti;
//	cus_t->e.time = time;
//	queue<cus> tq;
//	while(!q_cusnor.empty()){
//		tq.push(q_cusnor.front());
//		q_cusnor.front().t_wait+=nor[win_temp].c.e.time;
//		tq.pop();
//	}
//	while(!tq.empty()){
//		q_cusnor.push(tq.front());
//		tq.pop();
//	}
//	if(!q_cusnor.empty()){
//		nor[win_temp].c=q_cusnor.front();
//		q_cusnor.pop();
//	}
//	if (this->qu_clicked()) {
//		if (ui.moneyin->text() == NULL) {
//			QString a = "WARNING!";
//			QString b = QString::fromLocal8Bit("����Ϊ�գ�");
//			QMessageBox::warning(this, a, b);
//			return;
//		}
//		int money_t = ui.moneyin->text().toInt();
//		it->second.card_balance -= money_t;
//		QString a = "OK!";
//		QString b = QString::fromLocal8Bit("�ɹ�ȡ�");
//		QMessageBox::warning(this, a, b);
//	}
//	if (this->cun_clicked()) {
//		if (ui.moneyin->text() == NULL) {
//			QString a = "WARNING!";
//			QString b = QString::fromLocal8Bit("����Ϊ�գ�");
//			QMessageBox::warning(this, a, b);
//			return;
//		}
//		int money_t = ui.moneyin->text().toInt();
//		it->second.card_balance += money_t;
//		QString a = "OK!";
//		QString b = QString::fromLocal8Bit("�ɹ���");
//		QMessageBox::warning(this, a, b);
//	}
//	if (this->cha_clicked()) {
//		QString a = "ʣ����Ϊ";
//		QString b = QString::number(it->second.card_balance);
//		QMessageBox::warning(this, a, b);
//	}
//	this->close();
//}
