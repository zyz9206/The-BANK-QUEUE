#pragma once

#include <QDialog>
#include "ui_cus2.h"
#include "ui_cus3.h"
#include "cus3.h"

class cus2 : public QDialog
{
	Q_OBJECT

public:
	cus2(QDialog*parent = Q_NULLPTR);
	~cus2();

private:
	Ui::cus2 ui;
	cus3 cus3;
private slots:
	void ok_clicked();
};
