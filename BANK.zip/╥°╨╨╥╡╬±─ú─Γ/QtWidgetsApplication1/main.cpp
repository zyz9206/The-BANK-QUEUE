#include "Umain.h"
#include <QtWidgets/QApplication>
#include<iostream>
#include<cstdio>
#include<queue>
#include<algorithm> 
#include<fstream>
#include<cstdlib>
#include"myinclude.h"
extern win nor[3], spe[2];//������ͨ���ڣ�����vip 
extern int time_all = 0;
extern int cus_all=0;
extern map<string, cus> cusmap;
extern queue<cus> q_cusnor;//��ͨ�û��ȴ����� 
extern queue<cus> q_cusspe;//�����û��ȴ�����
extern int norleft, speleft;
extern int pos;
extern int win_temp;

int main(int argc, char *argv[])
{
	for (int i = 0; i < 3; i++) {//��ʼ�� 
		nor[i].free = true;
		nor[i].x = ordi;
		nor[i].num_now = 0;
	}
	for (int i = 0; i < 2; i++) {//��ʼ�� 
		spe[i].free = true;
		spe[i].num_now = 0;
		spe[i].x = special;
	}
	ifstream fp("customers.txt");
	if (!fp.is_open()) {
		cout << "Error Opening!";
		return 0;
	}
	while (!fp.eof()) {
		//	cout<<"!";
		cus tcus;
		string name;
		string card;
		int money;
		fp >> tcus.card_num >> tcus.card_balance;
		cusmap.insert(make_pair(tcus.card_num, tcus));
	}
		QApplication a(argc, argv);
		Umain w;
		w.show();
		return a.exec();
	
}
