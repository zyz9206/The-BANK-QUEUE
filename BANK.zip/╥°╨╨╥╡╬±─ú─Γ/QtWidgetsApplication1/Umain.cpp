#include "Umain.h"
#include"myinclude.h"
#include<qstring.h>
#include<fstream>
#include<qmessagebox.h>
using namespace std;

extern int time_all, cus_all;
extern map<string, cus> cusmap;
Umain::Umain(QDialog *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
void Umain::num_clicked()
{
    this->hide();
    Uqueue.show();
    Uqueue.exec();
    this->show();
}

void Umain::cus_clicked()
{
    this->close();
    cus1.show();
    cus1.exec();
    this->show();
}

void Umain::exit_clicked()
{
    this->close();
}

void Umain::time_clicked()
{
    QString ti;
    if (cus_all != 0) {
        int x = time_all / cus_all;
        ti = QString::number(x);
    }
    else ti = QString::fromLocal8Bit("��δ�й˿ͣ�");
    QString a = QString::fromLocal8Bit("ƽ���ȴ�ʱ��");
    QMessageBox::warning(this, a, ti);
}

void Umain::txt_updated()
{
    fstream fp("customers.txt");
    for (map<string, cus>::iterator it1 = cusmap.begin(); it1 != cusmap.end(); it1++) {
        fp << it1->second.card_num << " " << it1->second.card_balance << endl;
    }
}
